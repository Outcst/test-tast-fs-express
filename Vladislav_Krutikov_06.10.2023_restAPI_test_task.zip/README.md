COMMANDS:
npm i for install all dependencies

npm run start for start
